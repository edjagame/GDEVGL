Camera Controls:
W/S - Forward/Backward
A/D - Left/Right
Q/E - Up/Down

Exit Program - Esc